import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { GoogleGenAI } from '@google/genai';

const app=express();
app.use(cors());
app.use(express.json({limit:'1mb'}));
const PORT=process.env.PORT||8787;
const MODEL=process.env.GEMINI_MODEL||'gemini-3.7-flash';
const ai=process.env.GEMINI_API_KEY?new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY}):null;

async function generate(systemInstruction, contents){
 if(!ai) throw new Error('GEMINI_API_KEY is missing. Add it to server/.env and restart the backend.');
 const response=await ai.models.generateContent({model:MODEL,contents,config:{systemInstruction,temperature:0.35,maxOutputTokens:1200}});
 return response.text||'No AI response was returned.';
}

app.get('/api/health',(req,res)=>res.json({ok:true,aiConfigured:Boolean(ai),model:MODEL}));
app.post('/api/mentor',async(req,res)=>{try{const {question='',code='',level=1}=req.body;const text=await generate(`You are Code2Career AI Mentor, an expert software engineer and patient teacher. The student is doing a real developer task. Do NOT immediately give the final code. Give a progressive hint appropriate for hint level ${level}/4. Level 1 identifies what to inspect; level 2 narrows the likely area; level 3 explains the underlying concept; level 4 can provide detailed guidance and a small illustrative snippet but still encourage the student to implement it. Use simple language. Refer to the student's code when useful.`,`Student question:\n${question}\n\nStudent code:\n${code}`);res.json({answer:text});}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/review',async(req,res)=>{try{const {code='',language='Python',task=''}=req.body;const text=await generate(`You are Code2Career's Senior Code Reviewer. Review the submitted student code like a real engineering reviewer. Return a concise report with: Overall verdict; scores out of 100 for correctness, requirements, problem solving, debugging, code quality and efficiency; bugs; strengths; prioritized fixes; and one re-evaluation task. Do not rewrite the entire solution unless a tiny snippet is necessary. Be honest and specific.`,`Task:\n${task}\n\nLanguage: ${language}\n\nSubmitted code:\n${code}`);res.json({review:text});}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/challenge',async(req,res)=>{try{const {role='Python Intern',difficulty='Medium',skills=[]}=req.body;const text=await generate(`You are Code2Career's Product Manager. Create realistic internship-style developer tasks, not textbook MCQs. Include business context, requirements, acceptance criteria, edge cases, deliverables, evaluation rubric and progressive hints.`,`Create a ${difficulty} task for a ${role}. Focus skills: ${skills.join(', ')}. Return clean Markdown.`);res.json({challenge:text});}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/skill-gap',async(req,res)=>{try{const {scores={},history=''}=req.body;const text=await generate(`You are Code2Career's skill-gap analyst. Infer practical developer weaknesses from performance evidence. Separate strengths from gaps, explain evidence, rank gaps by priority, and recommend the smallest set of learning and real-world tasks that can close them. Avoid generic advice.`,`Scores:\n${JSON.stringify(scores,null,2)}\n\nPerformance evidence:\n${history}`);res.json({analysis:text});}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/plan',async(req,res)=>{try{const {gaps=[],goal='Software Developer',level='Beginner'}=req.body;const text=await generate(`You are Code2Career's personalized learning coach. Build a practical plan that moves a student from current weaknesses to job readiness. Use Learn -> Practice -> Real-world task -> AI evaluation -> Re-evaluation. Give a 7-day plan and one final re-evaluation task.`,`Target role: ${goal}\nLevel: ${level}\nSkill gaps: ${gaps.join(', ')}`);res.json({plan:text});}catch(e){res.status(500).json({error:e.message})}});
app.post('/api/internship',async(req,res)=>{try{const {role='Python Intern',task='',stage='PM'}=req.body;const text=await generate(`You are the ${stage} AI teammate inside Code2Career. Stay in role. If PM, clarify requirements. If QA, produce tests and edge cases. If Senior Developer, guide architecture without solving. If Code Reviewer, evaluate implementation.`,`Role: ${role}\nTask: ${task}`);res.json({message:text});}catch(e){res.status(500).json({error:e.message})}});
app.listen(PORT,()=>console.log(`Code2Career AI backend running at http://localhost:${PORT}`));
